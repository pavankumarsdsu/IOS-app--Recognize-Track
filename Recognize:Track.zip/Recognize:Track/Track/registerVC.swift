//
//  registerVC.swift
//  Track
//
//  Created by pavan kumar chalumuri on 12/5/18.
//  Copyright © 2018 pavan kumar chalumuri. All rights reserved.
//

import UIKit
import Firebase
import SVProgressHUD

class registerVC: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func registerButtonPressed(_ sender: Any) {
         SVProgressHUD.show()
        
        let email = emailTextField.text
        let password = passwordTextField.text
        
        if(email!.isEmpty || password!.isEmpty ){
            self.myAlerts(Title: "error", Message: "Please complete all the fields")
        }
        
        let isEmailAdressValid = isValidEmailAddress(inputEmail: email!)
        
        
         if isEmailAdressValid {
        Auth.auth().createUser(withEmail: emailTextField.text!, password: passwordTextField.text!) { (user, error) in
            
            if error != nil {
                print(error!)
            } else {
                print("Registration Successful!")
                
                SVProgressHUD.dismiss()
                
                self.performSegue(withIdentifier: "registerToMenu", sender: self)
            }
        }
         
         }else{
            self.myAlerts(Title: "error", Message: "Please Enter a valid email id")
        }
    
        
        
        
    }
    
   
    
    func isValidEmailAddress(inputEmail: String) -> Bool {
        
        let emailPattern = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
        var emailResultBoolean = true
        
        do {
            let emailString = inputEmail as NSString
            let regex = try NSRegularExpression(pattern: emailPattern)
            let results = regex.matches(in: inputEmail, range: NSRange(location: 0, length: emailString.length))
            
            if results.count == 0
            {
                emailResultBoolean = false
            }
            
        } catch let error as NSError {
            print(error.localizedDescription)
            emailResultBoolean = false
        }
        
        return  emailResultBoolean
    }
    
    func myAlerts(Title: String, Message: String){
        
        let myAlert = UIAlertController(title: Title, message: Message, preferredStyle: UIAlertController.Style.alert)
        
        let okAction = UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil)
        
        myAlert.addAction(okAction);
        self.present(myAlert, animated: true, completion: nil)
        return
        
    }
    

}
