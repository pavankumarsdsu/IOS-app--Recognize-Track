//
//  scanTrackVC.swift
//  Track
//
//  Created by pavan kumar chalumuri on 12/5/18.
//  Copyright © 2018 pavan kumar chalumuri. All rights reserved.
//

import UIKit
import AVFoundation
import Vision

class scanTrackVC: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {
    
    var prevObservation : VNDetectedObjectObservation?
    
    let confidenceLimit: Float = 0.4
    
    @IBOutlet var cameraView: UIView!
    @IBOutlet weak var overlayView: UIView! {
        didSet {
            self.overlayView.layer.borderColor = UIColor.green.cgColor
            self.overlayView.layer.borderWidth = 5
            self.overlayView.layer.cornerRadius = 8
            self.overlayView.backgroundColor = .clear
        }
    }
    
    let vsHandler = VNSequenceRequestHandler()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let videoResult = AVCaptureVideoDataOutput()
        videoResult.setSampleBufferDelegate(self, queue: DispatchQueue(label: "ObjectTrackingQueue"))
        self.capture.addOutput(videoResult)
        self.capture.startRunning()
        
        self.overlayView.frame = .zero
        self.cameraView.layer.addSublayer(self.camera)
        
    }
    
    lazy var capture: AVCaptureSession = {
        let sessionTake = AVCaptureSession()
        sessionTake.sessionPreset = AVCaptureSession.Preset.photo
        guard let backCamera =  AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back), let input = try? AVCaptureDeviceInput(device: backCamera) else {
            return sessionTake
        }
        sessionTake.addInput(input)
        return sessionTake
    }()
    
    lazy var camera: AVCaptureVideoPreviewLayer = AVCaptureVideoPreviewLayer(session: self.capture)
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.camera.frame = self.cameraView?.bounds ?? .zero
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        self.camera.frame = self.cameraView?.bounds ?? .zero
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func pressedSreen(_ sender: Any) {
        
        print("screen tapped")
        self.overlayView.frame.size = CGSize(width: 100, height: 100)
        self.overlayView.center = (sender as AnyObject).location(in: self.view)
        
        let originalRectangle = self.overlayView?.frame ?? .zero
        var convertedRectangle = self.camera.metadataOutputRectConverted(fromLayerRect: originalRectangle)
        convertedRectangle.origin.y = 1 - convertedRectangle.origin.y
        let currObservation = VNDetectedObjectObservation(boundingBox: convertedRectangle)
        self.prevObservation = currObservation
        
    }
    
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // CXPixelBuffer
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer), let lastObservation = self.prevObservation else {
            return
        }
        
        let request = VNTrackObjectRequest(detectedObjectObservation: lastObservation, completionHandler: self.vrUpdate)
        request.trackingLevel = VNRequestTrackingLevel.accurate
        
        do {
            try self.vsHandler.perform([request], on: pixelBuffer)
        } catch {
            print("error performing the object tracking request")
        }
        
    }
    
    func vrUpdate(_ request: VNRequest, error: Error?) {
        DispatchQueue.main.async {
            guard let currObservation = request.results?.first as? VNDetectedObjectObservation else {
                return
            }
            
            self.prevObservation = currObservation
            guard currObservation.confidence >= self.confidenceLimit else {
                self.overlayView.frame = .zero
                return
            }
            
            var currBox = currObservation.boundingBox
            currBox.origin.y = 1 - currBox.origin.y
            let newBox = self.camera.layerRectConverted(fromMetadataOutputRect: currBox)
            
            self.overlayView.frame = newBox
        }
    }
    
}
