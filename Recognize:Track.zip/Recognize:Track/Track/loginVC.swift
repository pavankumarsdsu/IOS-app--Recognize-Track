//
//  loginVC.swift
//  Track
//
//  Created by pavan kumar chalumuri on 12/5/18.
//  Copyright © 2018 pavan kumar chalumuri. All rights reserved.
//

import UIKit
import Firebase
import SVProgressHUD
import FBSDKLoginKit


class loginVC: UIViewController {
    
    @IBOutlet weak var emailtextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    
    @IBAction func loginButtonPressed(_ sender: Any) {
        
        SVProgressHUD.show()
        let email = emailtextField.text
        let password = passwordTextField.text
        
        
        if(email!.isEmpty || password!.isEmpty ){
            self.myAlerts(Title: "error", Message: "Please complete all the fields")
        }
        
        Auth.auth().signIn(withEmail: emailtextField.text!, password: passwordTextField.text!) { (user, error) in
            
            if error != nil {
                print(error!)
            } else {
                print("Log in successful!")
                
                SVProgressHUD.dismiss()
                
                self.performSegue(withIdentifier: "loginToMenu", sender: self)
                
            }
            
        }
        
        
    }
    
    func myAlerts(Title: String, Message: String){
        
        let myAlert = UIAlertController(title: Title, message: Message, preferredStyle: UIAlertController.Style.alert)
        
        let okAction = UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil)
        
        myAlert.addAction(okAction);
        self.present(myAlert, animated: true, completion: nil)
        return
        
    }

}
