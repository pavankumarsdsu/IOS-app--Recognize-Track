//
//  menuVC.swift
//  Track
//
//  Created by pavan kumar chalumuri on 12/5/18.
//  Copyright © 2018 pavan kumar chalumuri. All rights reserved.
//

import UIKit

class menuVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func logoutButtonPressed(_ sender: Any) {
        
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "login")
        self.present(vc!, animated: true, completion: nil)
        
    }
    
    @IBAction func uploadRecognizeButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "button1", sender: self)
    }
    
    @IBAction func scanRecognizeButtonPressed(_ sender: Any) {
        performSegue(withIdentifier: "button2", sender: self)
    }
    
    @IBAction func scanTrackButtonPressed(_ sender: Any) {
        performSegue(withIdentifier: "button3", sender: self)
    }
    
}
