//
//  ViewController.swift
//  Track
//
//  Created by pavan kumar chalumuri on 12/4/18.
//  Copyright © 2018 pavan kumar chalumuri. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func registerButtonPressed(_ sender: Any) {
         self.performSegue(withIdentifier: "welcomeToRegister", sender: self)
    }
    
    @IBAction func loginButtonPressed(_ sender: Any) {
         self.performSegue(withIdentifier: "welcomeToLogin", sender: self)
    }
    
}

