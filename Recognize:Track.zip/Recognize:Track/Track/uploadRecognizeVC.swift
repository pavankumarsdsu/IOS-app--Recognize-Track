//
//  uploadRecognizeVC.swift
//  Track
//
//  Created by pavan kumar chalumuri on 12/5/18.
//  Copyright © 2018 pavan kumar chalumuri. All rights reserved.
//

import UIKit
import CoreML
import Vision

class uploadRecognizeVC: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {

    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var imageInput: UIImageView!
    @IBOutlet weak var confidenceLabel: UILabel!
    @IBOutlet weak var commentLabel: UILabel!
    
    
    @IBAction func importImageButtonPressed(_ sender: Any) {
        let image = UIImagePickerController()
        image.delegate = self
        image.sourceType = UIImagePickerController.SourceType.photoLibrary
        image.allowsEditing = false
        
        self.present(image, animated: true)
        {
            
        }
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any])
    {
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        {
            imageInput.image = image
            
            let imageSaved: NSData = image.pngData()! as NSData
            
            UserDefaults.standard.set(imageSaved, forKey: "savedImage")
            
            let modelName =  mobileNet()
            let model = try! VNCoreMLModel(for: modelName.model)
            
            let data = UserDefaults.standard.object(forKey: "savedImage") as! NSData
            let requestHandler = VNImageRequestHandler(data: data as Data)
            let request = VNCoreMLRequest(model: model, completionHandler: myResultsMethod)
            try! requestHandler.perform( [ request] )
            
        }
        else
        {
            self.myAlerts(Title: "image invalid", Message: "Please import another image")
        }
        
        self.dismiss(animated: true, completion: nil)
        
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

    func myResultsMethod(request: VNRequest, error: Error?) {
        guard let results = request.results as? [VNClassificationObservation] else {
            fatalError("No results from the request")
        }
        
        var bestPrediction = ""
        var bestConfidence: VNConfidence = 0
        
        for classification in results {
            if(classification.confidence > bestConfidence) {
                bestConfidence = classification.confidence
                bestPrediction = classification.identifier
            }
        }
        
        print("predicted: \(bestPrediction) with confidence of \(bestConfidence) out of 1")
        
        self.resultLabel.text = bestPrediction
        self.confidenceLabel.text = "confidence is " + String(bestConfidence)
        
        switch bestConfidence {
        case 0..<0.5:
            self.commentLabel.text = "low confidence. May not be correct"
        case 0.5..<0.85:
            self.commentLabel.text = "good confidence. May be correct"
        case 0.85..<1:
            self.commentLabel.text = "Thats a great confidence. I think it is correct"
        case 0.5:
            self.commentLabel.text = "little ambigous"
        default:
            self.commentLabel.text = " is that confidence ok for you "
        }
        
    }
    
    func myAlerts(Title: String, Message: String){
        
        let myAlert = UIAlertController(title: Title, message: Message, preferredStyle: UIAlertController.Style.alert)
        
        let okAction = UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil)
        
        myAlert.addAction(okAction);
        self.present(myAlert, animated: true, completion: nil)
        return
        
    }
    
    
    
}
