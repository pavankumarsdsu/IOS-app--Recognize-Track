//
//  scanRecognizeVC.swift
//  Track
//
//  Created by pavan kumar chalumuri on 12/5/18.
//  Copyright © 2018 pavan kumar chalumuri. All rights reserved.
//

import UIKit
import AVFoundation
import Foundation
import Vision
import QuartzCore

class scanRecognizeVC: UIViewController, AVCapturePhotoCaptureDelegate {
   
    @IBOutlet weak var comments: UILabel!
    @IBOutlet weak var predictionTextView: UITextView!
    @IBOutlet weak var previewView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.configureCamera()
        
    }
    
    var capture : AVCaptureSession!
    var camOut : AVCapturePhotoOutput!
    var preview : AVCaptureVideoPreviewLayer!
    
    
    func configureCamera() {
        
        let machine = AVCaptureDevice.default(for: AVMediaType.video)
        
        capture = AVCaptureSession()
        capture.sessionPreset = AVCaptureSession.Preset.photo
        camOut = AVCapturePhotoOutput()
        
        if let input = try? AVCaptureDeviceInput(device: machine!) {
            if(capture.canAddInput(input)) {
                capture.addInput(input)
                
                if(capture.canAddOutput(camOut)) {
                    capture.addOutput(camOut)
                }
                
                preview = AVCaptureVideoPreviewLayer(session: capture)
                preview.videoGravity = AVLayerVideoGravity.resizeAspectFill
                preview.frame = previewView.bounds
                previewView.layer.addSublayer(preview)
                capture.startRunning()
                
            } else {
                self.myAlerts(Title: "error", Message: "cannot add input")
            }
        } else {
            self.myAlerts(Title: "error", Message: "no input found")
        }
        
        self.launch()
        
        
    }
    
    
    @objc func launch() {
        
        let configurations = AVCapturePhotoSettings()
        let previewPixels = configurations.availablePreviewPhotoPixelFormatTypes.first!
        let previewStyle = [
            kCVPixelBufferPixelFormatTypeKey as String: previewPixels,
            kCVPixelBufferWidthKey as String: 160,
            kCVPixelBufferHeightKey as String: 160
        ]
        configurations.previewPhotoFormat = previewStyle
        camOut.capturePhoto(with: configurations, delegate: self)
        
    }
    
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        if let error = error {
            print("error occured: \(error.localizedDescription)")
        }
        
        if let imageInformation = photo.fileDataRepresentation(), let image = UIImage(data: imageInformation) {
            self.prediction(image: image)
        }
    }
    
    
    func prediction(image: UIImage) {
        
        if let data = image.pngData() {
            let fileName = getDocumentsDirectory().appendingPathComponent("image.png")
            try? data.write(to: fileName)
        
            let model = try! VNCoreMLModel(for: mobileNet().model)
            let request = VNCoreMLRequest(model: model, completionHandler: predictionCompleted)
            let handler = VNImageRequestHandler(url: fileName)
            try! handler.perform([request])
            
        }
    }
    
    func predictionCompleted(request: VNRequest, error: Error?) {
        
        guard let results = request.results as? [VNClassificationObservation] else {
            fatalError("could not get any prediction output from ML model")
        }
        
        var bestPrediction = ""
        var confidence: VNConfidence = 0
        
        for classification in results {
            if classification.confidence > confidence {
                confidence = classification.confidence
                bestPrediction = classification.identifier
            }
        }
        
        self.predictionTextView.text = bestPrediction
        print(bestPrediction)
        
        let stringSize: Int = self.predictionTextView.text.characters.count
        self.predictionTextView.scrollRangeToVisible(NSMakeRange(stringSize-1, 0))
        
        switch confidence {
        case 0..<0.5:
            self.comments.text = "low confidence(<0.5). May not be correct"
        case 0.5..<1:
            self.comments.text = "good confidence(>0.5). May be correct"
        case 0.5:
            self.comments.text = "little ambigous"
        default:
            self.comments.text = " 0.5 confidence! is that confidence ok for you? "
        }
        
        Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.launch), userInfo: nil, repeats: false)
        
    }
    
    func removeShutterSoundTrick () {
        if let soundURL = Bundle.main.url(forResource: "blank", withExtension: "wav"){
            var mySound: SystemSoundID = 0
            AudioServicesCreateSystemSoundID(soundURL as CFURL, &mySound)
            AudioServicesPlaySystemSound(mySound)
        }
    }
    override func viewWillLayoutSubviews() {

        let orientation: UIDeviceOrientation = UIDevice.current.orientation
        print(orientation)

        switch (orientation) {
        case .portrait:
            preview?.connection?.videoOrientation = .portrait
        case .landscapeRight:
            preview?.connection?.videoOrientation = .landscapeLeft
        case .landscapeLeft:
            preview?.connection?.videoOrientation = .landscapeRight
        default:
            preview?.connection?.videoOrientation = .portrait
        }
        self.view.bringSubviewToFront(predictionTextView)
    }

    func configureTextView () {
        predictionTextView.layer.shadowColor = UIColor.black.cgColor
        predictionTextView.layer.shadowOffset = CGSize(width: 1, height: 1)
        predictionTextView.layer.shadowOpacity = 1
        predictionTextView.layer.shadowRadius = 1
        predictionTextView.layoutManager.allowsNonContiguousLayout = false
        self.view.bringSubviewToFront(predictionTextView)
    }

    
    func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let documentsDirectory = paths[0]
        return documentsDirectory
    }

    func myAlerts(Title: String, Message: String){
        
        let myAlert = UIAlertController(title: Title, message: Message, preferredStyle: UIAlertController.Style.alert)
        
        let okAction = UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil)
        
        myAlert.addAction(okAction);
        self.present(myAlert, animated: true, completion: nil)
        return
        
    }
    
}
